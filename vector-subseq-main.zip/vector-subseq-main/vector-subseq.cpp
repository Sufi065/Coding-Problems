#include <iostream>
#include<vector>
#include<cstring>
using namespace std;

void sub(int index,string orignal,string tillnow,vector<string>&v){
if(index==orignal.size())
{
    v.push_back(tillnow);
    return;
}
sub(index+1,orignal,tillnow+orignal[index],v);
sub(index+1,orignal,tillnow,v);
}


int main()
{
    vector<string>v;
    string orignal;
    cin>>orignal;
    sub(0,orignal,"",v);
    cout<<v.size()<<endl;
    for(int i=0;i<v.size();i++)
    cout<<v[i]<<endl;
    return 0;
}
